const { DynamoDBClient, PutItemCommand, ScanCommand } = require("@aws-sdk/client-dynamodb");
const { v4: uuidv4 } = require("uuid");
const jwt_decode = require("jwt-decode");

const ddb = new DynamoDBClient({ region: "ap-southeast-1" });
const TABLE_NAME = "Bids";

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }

  try {
    const authHeader = event.headers?.authorization || event.headers?.Authorization || "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;

    let username = "guest";
    if (token) {
      const decoded = jwt_decode(token);
      username = decoded.preferred_username || decoded.email || "guest";
    }

    const body = JSON.parse(event.body || "{}");
    const { productId, bidAmount } = body;

    if (!productId || !bidAmount) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "Missing productId or bidAmount" })
      };
    }

    // 查找当前产品的最高出价
    const result = await ddb.send(new ScanCommand({
      TableName: TABLE_NAME,
      FilterExpression: "productId = :pid",
      ExpressionAttributeValues: {
        ":pid": { S: productId }
      }
    }));

    const allBids = result.Items || [];
    const highest = Math.max(
      ...allBids.map(b => parseFloat(b.bidAmount?.N || "0")),
      0
    );

    if (parseFloat(bidAmount) <= highest) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: `Your bid must be higher than RM ${highest}` })
      };
    }

    const timestamp = new Date().toISOString();
    const bidId = uuidv4();

    await ddb.send(new PutItemCommand({
      TableName: TABLE_NAME,
      Item: {
        productId: { S: productId },
        timestamp: { S: timestamp },
        bidId: { S: bidId },
        bidAmount: { N: bidAmount.toString() },
        username: { S: username }
      }
    }));

    return {
      statusCode: 200,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ message: "✅ Bid placed successfully!" })
    };

  } catch (err) {
    console.error("❌ PlaceBid Error:", err);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Failed to place bid", detail: err.message })
    };
  }
};
