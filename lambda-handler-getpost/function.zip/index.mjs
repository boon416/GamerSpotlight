// === Lambda index.mjs ===
import { DynamoDBClient, ScanCommand } from '@aws-sdk/client-dynamodb';

const ddb = new DynamoDBClient({ region: 'ap-southeast-1' });
const TABLE_NAME = 'CommunityPosts';

export const handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS' || event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
      },
      body: '',
    };
  }

  try {
    const command = new ScanCommand({ TableName: TABLE_NAME });
    const result = await ddb.send(command);

    const posts = result.Items.map(item => ({
      postId: item.postId?.S || '',
      topic: item.topic?.S || '',
      content: item.content?.S || '',
      username: item.username?.S || '',
      createdAt: item.timestamp?.S || '',
      fileUrl: item.fileUrl?.S || ''
    }));

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
      },
      body: JSON.stringify({ posts }),
    };

  } catch (err) {
    console.error("❌ Failed to get posts:", err);
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'Failed to get posts', detail: err.message }),
    };
  }
};

// === package.json ===
{
  "type": "module",
  "dependencies": {
    "@aws-sdk/client-dynamodb": "^3.528.0"
  }
}
